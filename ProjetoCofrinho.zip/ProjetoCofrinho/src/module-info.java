/**
 * 
 */
/**
 * @author Guilherme Freitas dos Santos
 */
module ProjetoCofrinho {
}